Configurator for Homie for ESP8266
==================================

Sources of the UI to configure an ESP8266 loaded with an Homie firmware.

## Contribute

Contributions are very welcome!

To build assets, just run `npm run dev`.
This will build the public directory, and watch for changes in the `app` folder.
