Script: Firmware parser
=======================

This will allow you to get information about the binary firmware file.

## Usage

`python ./firmware_parser.py ~/firmware.bin`
