#ifndef SRC_HOMIE_H_
#define SRC_HOMIE_H_

#include "Homie.hpp"

#endif  // SRC_HOMIE_H_
