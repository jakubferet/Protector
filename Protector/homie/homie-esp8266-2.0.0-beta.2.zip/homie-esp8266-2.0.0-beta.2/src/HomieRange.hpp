#pragma once

struct HomieRange {
  bool isRange;
  uint16_t index;
};
